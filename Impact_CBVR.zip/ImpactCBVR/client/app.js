/*
 * Impact CBVR client
 * Receives JPEG frames over a WebSocket, decodes them with the browser's
 * native image decoder, uploads each as a WebGL texture, then renders it
 * twice (once per eye) through a barrel-distortion fragment shader so the
 * result looks correct through cardboard lenses. Also reads the device
 * gyroscope (DeviceOrientationEvent) and streams yaw/pitch back to the PC
 * so it can drive mouse-look.
 */

function dlog(msg) {
  const box = document.getElementById('debugLog');
  if (!box) { console.log(msg); return; }
  const ts = new Date().toLocaleTimeString();
  box.textContent += `[${ts}] ${msg}\n`;
  box.scrollTop = box.scrollHeight;
  console.log(msg);
}
window.addEventListener('error', (e) => dlog('JS-Fehler: ' + e.message));

const els = {
  overlay: document.getElementById('overlay'),
  connState: document.getElementById('connState'),
  serverUrl: document.getElementById('serverUrl'),
  connectBtn: document.getElementById('connectBtn'),
  enterVrBtn: document.getElementById('enterVrBtn'),
  exitVrBtn: document.getElementById('exitVrBtn'),
  canvas: document.getElementById('glcanvas'),
};

const state = {
  ws: null,
  connected: false,
  gyroActive: false,
  // All of these come from the PC app's "Lens / Cardboard" tab, pushed live
  // over the websocket as {type:'config', ...} messages. There is
  // intentionally no UI for them on the phone anymore.
  lens: { ipd: 63, fov: 90, k1: 0.22, k2: 0.06, chroma: 0.0, yOffset: 0, shape: 'round' },
  yaw: 0, pitch: 0, roll: 0,
};

// ---------- default server URL guess (same host, port 4243) ----------
(function guessUrl() {
  const host = location.hostname || '192.168.42.129';
  els.serverUrl.value = `ws://${host}:4243/ws`;
})();

function setConn(connected) {
  state.connected = connected;
  els.connState.textContent = connected ? 'Connected' : 'Not connected';
  els.connState.className = 'pill ' + (connected ? 'connected' : 'disconnected');
  els.enterVrBtn.disabled = !connected;
}

// ---------- WebSocket ----------
function connect() {
  const url = els.serverUrl.value.trim();
  dlog('Connecting to: ' + url);
  if (!url) { dlog('ERROR: Address field is empty.'); return; }
  if (!url.startsWith('ws://') && !url.startsWith('wss://')) {
    dlog('ERROR: Address must start with ws://, not http://. Example: ws://10.155.192.234:4243/ws');
    return;
  }

  let ws;
  try {
    ws = new WebSocket(url);
  } catch (e) {
    dlog('ERROR creating WebSocket connection: ' + e.message);
    return;
  }
  ws.binaryType = 'arraybuffer';
  state.ws = ws;
  els.connectBtn.disabled = true;
  els.connectBtn.textContent = 'Connecting...';

  const connectTimeout = setTimeout(() => {
    if (ws.readyState === WebSocket.CONNECTING) {
      dlog('TIMEOUT after 6s: Server did not respond. Check: is the server running (START button on the PC)? ' +
           'Is the IP address still correct? Is the Windows Firewall rule enabled? Is Wi-Fi disabled on the phone?');
      ws.close();
    }
  }, 6000);

  ws.onopen = () => {
    clearTimeout(connectTimeout);
    dlog('Connected! WebSocket offen.');
    setConn(true);
    els.connectBtn.disabled = false;
    els.connectBtn.textContent = 'Verbinden';
  };
  ws.onclose = (ev) => {
    clearTimeout(connectTimeout);
    dlog(`Connection closed. Code: ${ev.code}, Reason: "${ev.reason || '(none provided)'}"`);
    setConn(false);
    els.connectBtn.disabled = false;
    els.connectBtn.textContent = 'Verbinden';
  };
  ws.onerror = (ev) => {
    dlog('WebSocket ERROR (browsers often do not expose details — this usually means: ' +
         'server unreachable, wrong address, or the firewall is blocking it).');
    setConn(false);
  };

  ws.onmessage = (ev) => {
    if (typeof ev.data === 'string') {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === 'config') {
          state.lens.ipd = msg.ipd_mm ?? state.lens.ipd;
          state.lens.fov = msg.fov_deg ?? state.lens.fov;
          state.lens.k1 = msg.k1 ?? state.lens.k1;
          state.lens.k2 = msg.k2 ?? state.lens.k2;
          state.lens.chroma = msg.chroma_ab ?? state.lens.chroma;
          state.lens.yOffset = msg.y_offset_mm ?? state.lens.yOffset;
          state.lens.shape = msg.lens_shape ?? state.lens.shape;
          dlog('Lens configuration updated from the PC.');
        }
      } catch (e) { /* ignore */ }
      return;
    }
    // binary JPEG frame
    const blob = new Blob([ev.data], { type: 'image/jpeg' });
    const url2 = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => { gl_uploadFrame(img); URL.revokeObjectURL(url2); };
    img.src = url2;
  };
}
els.connectBtn.addEventListener('click', connect);

// ---------- Fullscreen / enter VR ----------
els.enterVrBtn.addEventListener('click', async () => {
  els.overlay.style.display = 'none';
  els.canvas.style.display = 'block';
  try { await document.documentElement.requestFullscreen(); } catch (e) {}
  try { if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape'); } catch (e) {}

  // Gyro permission must be requested from a direct user gesture on iOS
  // 13+; tapping "Enter VR" counts as that gesture, so we ask here
  // instead of via a separate settings button (there is no settings UI
  // on the phone anymore).
  try {
    if (typeof DeviceOrientationEvent !== 'undefined' &&
        typeof DeviceOrientationEvent.requestPermission === 'function') {
      const res = await DeviceOrientationEvent.requestPermission();
      if (res === 'granted') startGyro();
      else dlog('Gyroscope access denied — head tracking will remain disabled.');
    } else {
      startGyro();
    }
  } catch (e) { dlog('Gyroscope access failed: ' + e.message); }

  showExitBtn();
});

function startGyro() {
  window.addEventListener('deviceorientation', onOrientation, true);
  state.gyroActive = true;
}

// The exit ("✕") button only appears while the phone screen is actively
// being tapped, and fades out again after 3s of inactivity so it doesn't
// sit on top of the picture while just looking around in VR.
let exitHideTimer = null;
function showExitBtn() {
  els.exitVrBtn.style.display = 'flex';
  els.exitVrBtn.classList.add('visible');
  if (exitHideTimer) clearTimeout(exitHideTimer);
  exitHideTimer = setTimeout(() => {
    els.exitVrBtn.classList.remove('visible');
    setTimeout(() => {
      if (!els.exitVrBtn.classList.contains('visible')) els.exitVrBtn.style.display = 'none';
    }, 260); // let the opacity transition finish before removing from layout
  }, 3000);
}
els.canvas.addEventListener('pointerdown', showExitBtn);
els.canvas.addEventListener('touchstart', showExitBtn, { passive: true });

els.exitVrBtn.addEventListener('click', () => {
  if (exitHideTimer) clearTimeout(exitHideTimer);
  els.exitVrBtn.classList.remove('visible');
  els.exitVrBtn.style.display = 'none';
  els.overlay.style.display = 'flex';
  els.canvas.style.display = 'none';
  if (document.fullscreenElement) document.exitFullscreen();
});

let smoothYaw = 0, smoothPitch = 0;
function onOrientation(e) {
  // alpha: compass heading (yaw), beta: front-back tilt (pitch), gamma: left-right tilt (roll)
  const yaw = ((e.alpha || 0) / 180) * Math.PI;
  const pitch = ((e.beta || 0) / 180) * Math.PI;
  const roll = ((e.gamma || 0) / 180) * Math.PI;

  const s = 0.35; // smoothing factor, mirrors server "Smoothing" concept but applied locally too
  smoothYaw = smoothYaw + (yaw - smoothYaw) * (1 - s);
  smoothPitch = smoothPitch + (pitch - smoothPitch) * (1 - s);

  state.yaw = smoothYaw; state.pitch = smoothPitch; state.roll = roll;

  if (state.ws && state.ws.readyState === WebSocket.OPEN) {
    state.ws.send(JSON.stringify({ type: 'orientation', yaw: smoothYaw, pitch: smoothPitch, roll }));
  }
}

// ---------- WebGL stereo + barrel distortion ----------
const gl = els.canvas.getContext('webgl', { antialias: true });
let program, texture, aPosLoc, uEyeLoc, uK1Loc, uK2Loc, uChromaLoc, uAspectLoc;
let uFovScaleLoc, uIpdShiftLoc, uOffsetYLoc, uLensModeLoc;

function resizeCanvas() {
  els.canvas.width = window.innerWidth * (window.devicePixelRatio || 1);
  els.canvas.height = window.innerHeight * (window.devicePixelRatio || 1);
  if (gl) gl.viewport(0, 0, els.canvas.width, els.canvas.height);
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

const VERT_SRC = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  gl_Position = vec4(aPos, 0.0, 1.0);
}`;

// Barrel (pincushion-pre-correction) distortion, applied per-eye in its own
// half of the UV space, plus a light chromatic-aberration correction.
const FRAG_SRC = `
precision highp float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform float uEye;       // 0.0 = left, 1.0 = right
uniform float uK1;
uniform float uK2;
uniform float uChroma;
uniform float uFovScale;  // >1 = zoom out (wider FOV), <1 = zoom in (narrower FOV)
uniform float uIpdShift;  // per-eye horizontal shift (opposite sign each eye), in -1..1 NDC units
uniform float uOffsetY;   // vertical shift, same for both eyes, in -1..1 NDC units
uniform float uLensMode;  // 1.0 = round-lens barrel distortion, 0.0 = flat passthrough

vec2 distort(vec2 p, float k1, float k2) {
  float r2 = dot(p, p);
  float f = 1.0 + k1 * r2 + k2 * r2 * r2;
  return p * f;
}

void main() {
  vec2 c = (vUv * 2.0 - 1.0) * uFovScale; // -1..1 within this eye's viewport, FOV-scaled
  c.x -= uIpdShift; // pulls this eye's image left/right to match physical lens spacing
  c.y -= uOffsetY;  // moves both eyes' images up/down together

  vec2 dR = mix(c, distort(c, uK1, uK2 * 1.02), uLensMode);
  vec2 dG = mix(c, distort(c, uK1, uK2), uLensMode);
  vec2 dB = mix(c, distort(c, uK1, uK2 * 0.98), uLensMode);

  if (abs(dG.x) > 1.0 || abs(dG.y) > 1.0) { gl_FragColor = vec4(0.0,0.0,0.0,1.0); return; }

  vec2 uvR = (dR * 0.5 + 0.5);
  vec2 uvG = (dG * 0.5 + 0.5);
  vec2 uvB = (dB * 0.5 + 0.5);

  // map into left/right half of the source frame (fake3D duplicate-mono mode
  // shows the same full frame to both eyes; source texture is always full-frame)
  float r = texture2D(uTex, uvR).r;
  float g = texture2D(uTex, uvG).g;
  float b = texture2D(uTex, uvB).b;
  gl_FragColor = vec4(mix(vec3(texture2D(uTex, uvG).rgb), vec3(r,g,b), uChroma * uLensMode), 1.0);
}`;

function compile(src, type) {
  const sh = gl.createShader(type);
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(sh));
  }
  return sh;
}

function initGL() {
  if (!gl) return;
  program = gl.createProgram();
  gl.attachShader(program, compile(VERT_SRC, gl.VERTEX_SHADER));
  gl.attachShader(program, compile(FRAG_SRC, gl.FRAGMENT_SHADER));
  gl.linkProgram(program);
  gl.useProgram(program);

  const quad = new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]);
  const buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, quad, gl.STATIC_DRAW);
  aPosLoc = gl.getAttribLocation(program, 'aPos');
  gl.enableVertexAttribArray(aPosLoc);
  gl.vertexAttribPointer(aPosLoc, 2, gl.FLOAT, false, 0, 0);

  texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  // Browser <img> data has row 0 at the top, but WebGL texture v=0 is
  // conventionally the bottom. Without this flip the picture comes out
  // upside-down (and, combined with the eye-split math, mirrored-looking).
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

  uEyeLoc = gl.getUniformLocation(program, 'uEye');
  uK1Loc = gl.getUniformLocation(program, 'uK1');
  uK2Loc = gl.getUniformLocation(program, 'uK2');
  uChromaLoc = gl.getUniformLocation(program, 'uChroma');
  uFovScaleLoc = gl.getUniformLocation(program, 'uFovScale');
  uIpdShiftLoc = gl.getUniformLocation(program, 'uIpdShift');
  uOffsetYLoc = gl.getUniformLocation(program, 'uOffsetY');
  uLensModeLoc = gl.getUniformLocation(program, 'uLensMode');
}
initGL();

let currentFrame = null;
function gl_uploadFrame(img) {
  currentFrame = img;
}

// Reference FOV the barrel-distortion constants (k1/k2) were tuned for.
const REFERENCE_FOV_DEG = 90;
// Reference IPD: at this value there is no extra horizontal shift.
const REFERENCE_IPD_MM = 63;
// How much one extra mm of IPD pulls each eye's circle apart on screen.
const IPD_SHIFT_PER_MM = 0.02;
// How much one extra mm of Y-offset moves both eyes' images up/down.
const Y_OFFSET_SHIFT_PER_MM = 0.02;

function render() {
  requestAnimationFrame(render);
  if (!gl || !program) return;
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);
  if (!currentFrame) return;

  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, currentFrame);

  const w = els.canvas.width, h = els.canvas.height;
  gl.uniform1f(uK1Loc, state.lens.k1);
  gl.uniform1f(uK2Loc, state.lens.k2);
  gl.uniform1f(uChromaLoc, state.lens.chroma);

  // FOV: wider FOV than the reference means each screen pixel should cover
  // more of the source image, i.e. we sample a larger UV range -> scale > 1.
  const fovScale = Math.tan((state.lens.fov * Math.PI / 180) / 2) /
                    Math.tan((REFERENCE_FOV_DEG * Math.PI / 180) / 2);
  gl.uniform1f(uFovScaleLoc, fovScale);

  const ipdShift = (state.lens.ipd - REFERENCE_IPD_MM) * IPD_SHIFT_PER_MM;
  const yOffset = state.lens.yOffset * Y_OFFSET_SHIFT_PER_MM;
  gl.uniform1f(uOffsetYLoc, yOffset);

  // "round" = classic circular Cardboard-lens view with barrel distortion.
  // "flat"  = still split left/right for stereo, just plain rectangles
  //           with no lens distortion. Controlled only from the PC app.
  const lensMode = state.lens.shape === 'round' ? 1.0 : 0.0;
  gl.uniform1f(uLensModeLoc, lensMode);

  // Left eye: pulled toward/away from center depending on IPD.
  gl.viewport(0, 0, w / 2, h);
  gl.uniform1f(uEyeLoc, 0.0);
  gl.uniform1f(uIpdShiftLoc, -ipdShift);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

  // Right eye.
  gl.viewport(w / 2, 0, w / 2, h);
  gl.uniform1f(uEyeLoc, 1.0);
  gl.uniform1f(uIpdShiftLoc, ipdShift);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
}
requestAnimationFrame(render);
