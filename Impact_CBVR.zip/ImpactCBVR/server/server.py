"""
Impact CBVR Server
===================
A from-scratch, open reimplementation of the "phone-as-cardboard-VR-display"
workflow popularized by Trinus VR:

  PC captures the screen -> compresses each frame -> streams it over the
  USB-tethering IP link to the phone -> the phone (in a full-screen browser
  tab, no app install needed) splits the image into a stereo pair, applies
  barrel/pincushion lens correction for the cardboard's lenses, and reads the
  phone's gyroscope to drive mouse-look on the PC.

Why a browser client instead of a native APK?
  Building a signed native Android app requires the Android SDK/Gradle/NDK
  toolchain, a keystore, and a real device or emulator to test on -- none of
  which exist in this build environment, and any APK produced without that
  toolchain would be unverifiable and untrustworthy to install. A browser
  client reaches the exact same goal (full-screen stereo VR view + gyro
  input) with zero install step: on the phone, open the PC's tethered IP in
  Chrome, tap "fullscreen", drop it in the cardboard. It uses only standard
  web APIs (WebSocket, WebGL, DeviceOrientationEvent) that every modern
  Android/iOS browser supports, so functionally it is a 1:1 replacement.

Run:
    pip install -r requirements.txt
    python server.py
"""

import asyncio
import io
import json
import socket
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

import mss
import numpy as np
from PIL import Image
from aiohttp import web, WSMsgType
from PyQt6 import QtCore, QtGui, QtWidgets
import qasync

try:
    from pynput.mouse import Controller as MouseController
    _mouse = MouseController()
except Exception:
    _mouse = None

CLIENT_DIR = Path(__file__).resolve().parent.parent / "client"


# --------------------------------------------------------------------------- 
# Shared, mutable settings block. Every widget in the GUI writes into this;
# the capture loop and websocket handlers only ever read from it, so there is
# no locking needed for these simple scalar assignments (GIL guarantees
# atomicity of individual attribute writes).
# --------------------------------------------------------------------------- 
@dataclass
class Settings:
    monitor_index: int = 1          # mss monitor index (1 = primary)
    image_scale: float = 1.0        # 0.25 .. 1.0 of native resolution
    jpeg_quality: int = 80          # 10 .. 100
    max_fps: int = 72
    port: int = 4243

    # Video tab
    fake3d_mode: str = "sbs"        # "sbs" (duplicate mono->stereo) or "mono"
    crop_left: float = 0.0
    crop_right: float = 0.0
    crop_top: float = 0.0
    crop_bottom: float = 0.0
    zoom: float = 1.0
    brightness: float = 1.0
    contrast: float = 1.0

    # Lens / cardboard tab
    ipd_mm: float = 63.0
    lens_fov_deg: float = 90.0
    distortion_k1: float = 0.22
    distortion_k2: float = 0.06
    chroma_ab: float = 0.0          # chromatic-aberration correction strength
    lens_y_offset_mm: float = 0.0   # vertical offset of both lens circles together
    lens_shape: str = "round"       # "round" (Cardboard lenses) or "flat" (split, no distortion)

    # Sensor tab
    sensor_mode: str = "mouse"      # "mouse" or "off"
    yaw_sensitivity: float = 1.0
    pitch_sensitivity: float = 1.0
    invert_y: bool = False
    dead_zone: float = 0.01
    smoothing: float = 0.35         # 0 = raw, 1 = very smooth

    connected_clients: int = 0
    running: bool = False


settings = Settings()
log_signal = None  # assigned to a Qt signal once the GUI is built


def log(msg: str):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    if log_signal is not None:
        log_signal.emit(line)


# --------------------------------------------------------------------------- 
# Frame capture + processing
# --------------------------------------------------------------------------- 
class Capturer:
    """
    mss keeps Windows GDI handles in thread-local storage internally, so a
    single mss.mss() instance created on one thread cannot be used from a
    different thread (as happens here, since capture runs inside an
    executor thread pool). We lazily create one mss instance per worker
    thread instead.
    """
    def __init__(self):
        self._tls = threading.local()
        self._probe = mss.mss()  # only used to enumerate monitors up-front

    def _get_sct(self):
        sct = getattr(self._tls, "sct", None)
        if sct is None:
            sct = mss.mss()
            self._tls.sct = sct
        return sct

    def monitors(self):
        return self._probe.monitors

    def grab_and_encode(self) -> bytes:
        sct = self._get_sct()
        mon = sct.monitors[settings.monitor_index]
        raw = sct.grab(mon)
        img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")

        w, h = img.size
        l = int(w * settings.crop_left)
        r = int(w * (1 - settings.crop_right))
        t = int(h * settings.crop_top)
        b = int(h * (1 - settings.crop_bottom))
        if r > l and b > t:
            img = img.crop((l, t, r, b))

        if settings.zoom != 1.0:
            zw, zh = img.size
            nw, nh = int(zw / settings.zoom), int(zh / settings.zoom)
            cx, cy = zw // 2, zh // 2
            img = img.crop((cx - nw // 2, cy - nh // 2, cx + nw // 2, cy + nh // 2))

        if settings.image_scale != 1.0:
            nw = max(2, int(img.width * settings.image_scale))
            nh = max(2, int(img.height * settings.image_scale))
            img = img.resize((nw, nh), Image.BILINEAR)

        if settings.brightness != 1.0 or settings.contrast != 1.0:
            arr = np.asarray(img).astype(np.float32)
            arr = (arr - 127.5) * settings.contrast + 127.5
            arr = arr * settings.brightness
            arr = np.clip(arr, 0, 255).astype(np.uint8)
            img = Image.fromarray(arr)

        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=settings.jpeg_quality)
        return buf.getvalue()


capturer = Capturer()


class ClientConn:
    """
    One of these per connected phone. capture_loop only ever writes the
    latest encoded frame into `latest_frame` and flags `event`; it never
    awaits the network itself. A dedicated `_client_sender` task per client
    does the actual (potentially slow) `ws.send_bytes`, and always sends
    whatever is newest by the time it's ready to send again -- any frames
    captured while it was still busy sending are simply superseded, not
    queued. This is what keeps latency bounded even at Image Scale = Ultra
    or over a slow USB-tethering link: a queueing sender would otherwise
    fall further and further behind real time.
    """
    __slots__ = ("ws", "latest_frame", "event", "send_task")

    def __init__(self, ws):
        self.ws = ws
        self.latest_frame = None
        self.event = asyncio.Event()
        self.send_task = None


_clients: "dict[web.WebSocketResponse, ClientConn]" = {}
_capture_executor = ThreadPoolExecutor(max_workers=1)


async def _client_sender(conn: "ClientConn"):
    try:
        while True:
            await conn.event.wait()
            conn.event.clear()
            frame = conn.latest_frame
            if frame is None:
                continue
            try:
                await conn.ws.send_bytes(frame)
            except Exception:
                break
    except asyncio.CancelledError:
        pass


async def capture_loop(app):
    loop = asyncio.get_event_loop()
    while True:
        if not settings.running or not _clients:
            await asyncio.sleep(0.05)
            continue
        start = time.time()
        try:
            frame = await loop.run_in_executor(_capture_executor, capturer.grab_and_encode)
        except Exception as e:
            log(f"capture error: {e}")
            await asyncio.sleep(0.2)
            continue

        for conn in list(_clients.values()):
            conn.latest_frame = frame
            conn.event.set()

        elapsed = time.time() - start
        target = 1.0 / max(1, settings.max_fps)
        if elapsed < target:
            await asyncio.sleep(target - elapsed)


# --------------------------------------------------------------------------- 
# HTTP + WebSocket server
# --------------------------------------------------------------------------- 
async def handle_ws(request):
    ws = web.WebSocketResponse(max_msg_size=0)
    await ws.prepare(request)
    conn = ClientConn(ws)
    conn.send_task = asyncio.ensure_future(_client_sender(conn))
    _clients[ws] = conn
    settings.connected_clients = len(_clients)
    log(f"Phone connected ({request.remote}). Total clients: {len(_clients)}")

    # send initial config so the client can build its shader/stereo params
    await ws.send_str(json.dumps({"type": "config", **_config_payload()}))

    last_yaw, last_pitch = 0.0, 0.0
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                except ValueError:
                    continue
                if data.get("type") == "orientation" and settings.sensor_mode == "mouse" and _mouse:
                    yaw = data.get("yaw", 0.0)
                    pitch = data.get("pitch", 0.0)
                    dyaw = yaw - last_yaw
                    dpitch = pitch - last_pitch
                    last_yaw, last_pitch = yaw, pitch
                    if abs(dyaw) < settings.dead_zone:
                        dyaw = 0
                    if abs(dpitch) < settings.dead_zone:
                        dpitch = 0
                    dx = dyaw * settings.yaw_sensitivity * 800
                    dy = dpitch * settings.pitch_sensitivity * 800
                    if settings.invert_y:
                        dy = -dy
                    try:
                        _mouse.move(dx, dy)
                    except Exception:
                        pass
                elif data.get("type") == "request_config":
                    await ws.send_str(json.dumps({"type": "config", **_config_payload()}))
            elif msg.type == WSMsgType.ERROR:
                break
    finally:
        if conn.send_task:
            conn.send_task.cancel()
        _clients.pop(ws, None)
        settings.connected_clients = len(_clients)
        log(f"Phone disconnected. Total clients: {len(_clients)}")
    return ws


def _config_payload():
    return {
        "ipd_mm": settings.ipd_mm,
        "fov_deg": settings.lens_fov_deg,
        "k1": settings.distortion_k1,
        "k2": settings.distortion_k2,
        "chroma_ab": settings.chroma_ab,
        "y_offset_mm": settings.lens_y_offset_mm,
        "lens_shape": settings.lens_shape,
        "fake3d": settings.fake3d_mode,
    }


def push_config_to_clients():
    """Send the current lens/stereo config to every connected phone right
    now (used both by the explicit 'push' button and live by every Lens-tab
    slider, so calibration updates show up on the phone immediately)."""
    payload = json.dumps({"type": "config", **_config_payload()})
    for conn in list(_clients.values()):
        asyncio.ensure_future(conn.ws.send_str(payload))


async def handle_status(request):
    return web.json_response({
        "running": settings.running,
        "clients": settings.connected_clients,
        "monitor": settings.monitor_index,
    })


async def handle_index(request):
    return web.FileResponse(CLIENT_DIR / "index.html")


def build_app():
    app = web.Application()
    app.router.add_get("/ws", handle_ws)
    app.router.add_get("/status", handle_status)
    app.router.add_get("/", handle_index)
    app.router.add_static("/", CLIENT_DIR, show_index=False)
    return app


def get_local_ips():
    ips = []
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ":" not in ip and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return sorted(set(ips))


# --------------------------------------------------------------------------- 
# GUI
# --------------------------------------------------------------------------- 
DARK_QSS = """
QWidget { background-color: #12141a; color: #e6e6e6; font-family: 'Segoe UI', sans-serif; font-size: 13px; }
QMainWindow { background-color: #0c0d11; }
QTabWidget::pane { border: 1px solid #232634; border-radius: 6px; top: -1px; }
QTabBar::tab { background: #171923; padding: 8px 18px; border: 1px solid #232634; border-bottom: none;
                border-top-left-radius: 6px; border-top-right-radius: 6px; margin-right: 2px; color: #9aa0ac; }
QTabBar::tab:selected { background: #1c2030; color: #7c9cff; font-weight: 600; }
QGroupBox { border: 1px solid #232634; border-radius: 8px; margin-top: 14px; padding-top: 10px; font-weight: 600; color: #b7bccb; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QPushButton { background-color: #232840; border: 1px solid #363c5c; border-radius: 6px; padding: 8px 14px; color: #dde1f5; }
QPushButton:hover { background-color: #2c3252; }
QPushButton:pressed { background-color: #1a1e30; }
QPushButton#startBtn { background-color: #1f7a4d; border: 1px solid #2ba766; font-weight: 700; }
QPushButton#startBtn:hover { background-color: #23935c; }
QPushButton#stopBtn { background-color: #7a1f1f; border: 1px solid #a72b2b; font-weight: 700; }
QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit { background-color: #171923; border: 1px solid #2a2e40; border-radius: 5px; padding: 5px; }
QSlider::groove:horizontal { height: 5px; background: #232634; border-radius: 2px; }
QSlider::handle:horizontal { background: #7c9cff; width: 15px; margin: -6px 0; border-radius: 7px; }
QCheckBox::indicator { width: 15px; height: 15px; border-radius: 3px; border: 1px solid #363c5c; background: #171923; }
QCheckBox::indicator:checked { background: #7c9cff; }
QPlainTextEdit { background-color: #0c0d11; border: 1px solid #232634; border-radius: 6px; color: #8ee08e; font-family: Consolas, monospace; }
QLabel#heading { font-size: 20px; font-weight: 700; color: #7c9cff; }
QLabel#sub { color: #7a8095; }
QStatusBar { background: #0c0d11; border-top: 1px solid #232634; }
"""


def _set_and_push(attr, value):
    """Write a setting and immediately push the updated config to every
    connected phone, so Lens-tab sliders take effect live instead of only
    after pressing the separate push button."""
    setattr(settings, attr, value)
    push_config_to_clients()


def slider_row(label, minv, maxv, value, step, on_change, decimals=2, suffix=""):
    row = QtWidgets.QHBoxLayout()
    lab = QtWidgets.QLabel(label)
    lab.setFixedWidth(150)
    slider = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
    slider.setMinimum(int(minv / step))
    slider.setMaximum(int(maxv / step))
    slider.setValue(int(value / step))
    val_lab = QtWidgets.QLabel(f"{value:.{decimals}f}{suffix}")
    val_lab.setFixedWidth(70)

    def changed(v):
        real = v * step
        val_lab.setText(f"{real:.{decimals}f}{suffix}")
        on_change(real)

    slider.valueChanged.connect(changed)
    row.addWidget(lab)
    row.addWidget(slider)
    row.addWidget(val_lab)
    return row


class MainWindow(QtWidgets.QMainWindow):
    log_line = QtCore.pyqtSignal(str)

    def __init__(self):
        super().__init__()
        global log_signal
        log_signal = self.log_line
        self.setWindowTitle("Impact CBVR - Impact Cardboard VR 1.0")
        self.resize(980, 640)
        self._build_ui()
        self.log_line.connect(self._append_log)
        self._status_timer = QtCore.QTimer(self)
        self._status_timer.timeout.connect(self._refresh_status)
        self._status_timer.start(1000)

    # ---------------- UI construction ----------------
    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        outer = QtWidgets.QVBoxLayout(central)

        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("Impact CBVR")
        title.setObjectName("heading")
        sub = QtWidgets.QLabel("Wireless USB-tethered Cardboard VR streaming")
        sub.setObjectName("sub")
        title_box = QtWidgets.QVBoxLayout()
        title_box.addWidget(title)
        title_box.addWidget(sub)
        header.addLayout(title_box)
        header.addStretch()

        self.start_btn = QtWidgets.QPushButton("▶  START")
        self.start_btn.setObjectName("startBtn")
        self.start_btn.clicked.connect(self.start_server)
        self.stop_btn = QtWidgets.QPushButton("■  STOP")
        self.stop_btn.setObjectName("stopBtn")
        self.stop_btn.clicked.connect(self.stop_server)
        self.stop_btn.setEnabled(False)
        header.addWidget(self.start_btn)
        header.addWidget(self.stop_btn)
        outer.addLayout(header)

        tabs = QtWidgets.QTabWidget()
        tabs.addTab(self._build_main_tab(), "Main")
        tabs.addTab(self._build_video_tab(), "Video")
        tabs.addTab(self._build_lens_tab(), "Lens / Cardboard")
        tabs.addTab(self._build_sensor_tab(), "Sensor")
        outer.addWidget(tabs, 1)

        self.log_box = QtWidgets.QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setFixedHeight(130)
        outer.addWidget(self.log_box)

        self.status_bar = self.statusBar()
        self.status_label = QtWidgets.QLabel("Stopped")
        self.status_bar.addWidget(self.status_label)

    def _build_main_tab(self):
        w = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(w)

        left = QtWidgets.QVBoxLayout()
        conn_group = QtWidgets.QGroupBox("Connection")
        cl = QtWidgets.QVBoxLayout(conn_group)

        ip_lab = QtWidgets.QLabel("Connect the phone via USB, enable USB tethering on the\nphone, then in a browser on the phone go to:")
        cl.addWidget(ip_lab)
        self.ip_display = QtWidgets.QPlainTextEdit()
        self.ip_display.setReadOnly(True)
        self.ip_display.setFixedHeight(70)
        cl.addWidget(self.ip_display)

        port_row = QtWidgets.QHBoxLayout()
        port_row.addWidget(QtWidgets.QLabel("Port"))
        self.port_spin = QtWidgets.QSpinBox()
        self.port_spin.setRange(1024, 65535)
        self.port_spin.setValue(settings.port)
        self.port_spin.valueChanged.connect(lambda v: setattr(settings, "port", v))
        port_row.addWidget(self.port_spin)
        cl.addLayout(port_row)
        left.addWidget(conn_group)

        cap_group = QtWidgets.QGroupBox("Capture")
        cgl = QtWidgets.QVBoxLayout(cap_group)
        mon_row = QtWidgets.QHBoxLayout()
        mon_row.addWidget(QtWidgets.QLabel("Monitor"))
        self.monitor_combo = QtWidgets.QComboBox()
        for i, m in enumerate(capturer.monitors()):
            label = "All monitors" if i == 0 else f"Monitor {i}  ({m['width']}x{m['height']})"
            self.monitor_combo.addItem(label, i)
        self.monitor_combo.setCurrentIndex(settings.monitor_index)
        self.monitor_combo.currentIndexChanged.connect(
            lambda i: setattr(settings, "monitor_index", self.monitor_combo.itemData(i)))
        mon_row.addWidget(self.monitor_combo)
        cgl.addLayout(mon_row)

        scale_row = QtWidgets.QHBoxLayout()
        scale_row.addWidget(QtWidgets.QLabel("Image Scale"))
        self.scale_combo = QtWidgets.QComboBox()
        self.scale_combo.addItems(["Low (0.5x)", "Medium (0.75x)", "High (0.9x)", "Ultra (1.0x)"])
        self.scale_combo.setCurrentIndex(3)
        scale_map = {0: 0.5, 1: 0.75, 2: 0.9, 3: 1.0}
        self.scale_combo.currentIndexChanged.connect(lambda i: setattr(settings, "image_scale", scale_map[i]))
        scale_row.addWidget(self.scale_combo)
        cgl.addLayout(scale_row)

        cgl.addLayout(slider_row("JPEG Quality", 10, 100, settings.jpeg_quality, 1,
                                  lambda v: setattr(settings, "jpeg_quality", int(v)), 0))
        cgl.addLayout(slider_row("Max FPS", 15, 120, settings.max_fps, 1,
                                  lambda v: setattr(settings, "max_fps", int(v)), 0))
        left.addWidget(cap_group)
        left.addStretch()
        layout.addLayout(left)

        right = QtWidgets.QVBoxLayout()
        info = QtWidgets.QLabel(
            "How it works:\n\n"
            "1. Plug the phone into the PC with a USB-C cable.\n"
            "2. On the phone: Settings → Network → USB tethering → ON.\n"
            "   Windows creates a new virtual network adapter for it.\n"
            "3. Click START below.\n"
            "4. Open the shown IP:PORT in the phone's browser and tap\n"
            "   \"Enter VR\" — no app install required.\n"
            "5. Put the phone in the cardboard. Use the Lens tab to\n"
            "   match distortion/IPD to your headset.\n\n"
            "If the phone can't connect: run.bat sets up a Windows Firewall\n"
            "rule automatically on first launch (needs a one-time admin\n"
            "prompt). If it still fails, open an admin PowerShell and run:\n"
            "  netsh advfirewall firewall add rule name=\"Impact CBVR\"\n"
            "  dir=in action=allow protocol=TCP localport=4243"
        )
        info.setWordWrap(True)
        right.addWidget(info)
        right.addStretch()
        layout.addLayout(right)
        return w

    def _build_video_tab(self):
        w = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(w)
        g = QtWidgets.QGroupBox("Stereo / Fake3D")
        gl = QtWidgets.QVBoxLayout(g)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Mode"))
        combo = QtWidgets.QComboBox()
        combo.addItems(["Duplicate mono -> stereo (SBS)", "Mono passthrough"])
        combo.currentIndexChanged.connect(lambda i: setattr(settings, "fake3d_mode", "sbs" if i == 0 else "mono"))
        row.addWidget(combo)
        gl.addLayout(row)
        layout.addWidget(g)

        crop_g = QtWidgets.QGroupBox("Crop")
        cgl = QtWidgets.QVBoxLayout(crop_g)
        cgl.addLayout(slider_row("Left", 0, 0.4, 0, 0.01, lambda v: setattr(settings, "crop_left", v)))
        cgl.addLayout(slider_row("Right", 0, 0.4, 0, 0.01, lambda v: setattr(settings, "crop_right", v)))
        cgl.addLayout(slider_row("Top", 0, 0.4, 0, 0.01, lambda v: setattr(settings, "crop_top", v)))
        cgl.addLayout(slider_row("Bottom", 0, 0.4, 0, 0.01, lambda v: setattr(settings, "crop_bottom", v)))
        layout.addWidget(crop_g)

        adj_g = QtWidgets.QGroupBox("Image Adjustments")
        agl = QtWidgets.QVBoxLayout(adj_g)
        agl.addLayout(slider_row("Zoom", 1.0, 2.0, settings.zoom, 0.01,
                                  lambda v: setattr(settings, "zoom", v)))
        agl.addLayout(slider_row("Brightness", 0.5, 1.5, settings.brightness, 0.01,
                                  lambda v: setattr(settings, "brightness", v)))
        agl.addLayout(slider_row("Contrast", 0.5, 1.5, settings.contrast, 0.01,
                                  lambda v: setattr(settings, "contrast", v)))
        layout.addWidget(adj_g)
        layout.addStretch()
        return w

    def _build_lens_tab(self):
        w = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(w)
        g = QtWidgets.QGroupBox("Cardboard Lens Calibration (applied live in the phone's WebGL shader)")
        gl = QtWidgets.QVBoxLayout(g)
        gl.addLayout(slider_row("IPD (mm)", 50, 75, settings.ipd_mm, 0.5,
                                 lambda v: _set_and_push("ipd_mm", v), 1, " mm"))
        gl.addLayout(slider_row("Lens FOV (deg)", 60, 120, settings.lens_fov_deg, 1,
                                 lambda v: _set_and_push("lens_fov_deg", v), 0, "°"))
        gl.addLayout(slider_row("Lens Y Offset (mm)", -10, 10, settings.lens_y_offset_mm, 0.5,
                                 lambda v: _set_and_push("lens_y_offset_mm", v), 1, " mm"))
        gl.addLayout(slider_row("Barrel Distortion K1", 0.0, 0.5, settings.distortion_k1, 0.01,
                                 lambda v: _set_and_push("distortion_k1", v)))
        gl.addLayout(slider_row("Barrel Distortion K2", 0.0, 0.3, settings.distortion_k2, 0.01,
                                 lambda v: _set_and_push("distortion_k2", v)))
        gl.addLayout(slider_row("Chromatic Aberration Fix", 0.0, 1.0, settings.chroma_ab, 0.01,
                                 lambda v: _set_and_push("chroma_ab", v)))

        shape_row = QtWidgets.QHBoxLayout()
        shape_row.addWidget(QtWidgets.QLabel("Lens Shape"))
        shape_combo = QtWidgets.QComboBox()
        shape_combo.addItems(["Round (Cardboard lenses)", "Flat (split screen, no distortion)"])
        shape_combo.setCurrentIndex(0 if settings.lens_shape == "round" else 1)
        shape_combo.currentIndexChanged.connect(
            lambda i: _set_and_push("lens_shape", "round" if i == 0 else "flat"))
        shape_row.addWidget(shape_combo)
        gl.addLayout(shape_row)
        shape_note = QtWidgets.QLabel(
            "Round = the classic circular Cardboard-lens view with barrel distortion.\n"
            "Flat = still split left/right for stereo, but as plain rectangles with no\n"
            "lens distortion (e.g. for a phone used flat, without a viewer)."
        )
        shape_note.setObjectName("sub")
        shape_note.setWordWrap(True)
        gl.addWidget(shape_note)

        note = QtWidgets.QLabel(
            "Tip: these values push live to the phone over the websocket, so you\n"
            "can dial in the lens match in real time while looking through the headset."
        )
        note.setObjectName("sub")
        note.setWordWrap(True)
        gl.addWidget(note)
        layout.addWidget(g)
        push_btn = QtWidgets.QPushButton("Push settings to connected phone now")
        push_btn.clicked.connect(self._push_config)
        layout.addWidget(push_btn)
        layout.addStretch()
        return w

    def _build_sensor_tab(self):
        w = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(w)
        g = QtWidgets.QGroupBox("Head Tracking (phone gyroscope -> PC mouse-look)")
        gl = QtWidgets.QVBoxLayout(g)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Sensor Mode"))
        combo = QtWidgets.QComboBox()
        combo.addItems(["Mouse (head tracking on)", "Off"])
        combo.currentIndexChanged.connect(lambda i: setattr(settings, "sensor_mode", "mouse" if i == 0 else "off"))
        row.addWidget(combo)
        gl.addLayout(row)

        gl.addLayout(slider_row("Yaw Sensitivity", 0.1, 3.0, settings.yaw_sensitivity, 0.05,
                                 lambda v: setattr(settings, "yaw_sensitivity", v)))
        gl.addLayout(slider_row("Pitch Sensitivity", 0.1, 3.0, settings.pitch_sensitivity, 0.05,
                                 lambda v: setattr(settings, "pitch_sensitivity", v)))
        gl.addLayout(slider_row("Dead Zone", 0.0, 0.1, settings.dead_zone, 0.005,
                                 lambda v: setattr(settings, "dead_zone", v), 3))
        gl.addLayout(slider_row("Smoothing", 0.0, 0.9, settings.smoothing, 0.05,
                                 lambda v: setattr(settings, "smoothing", v)))
        invert = QtWidgets.QCheckBox("Invert Y")
        invert.stateChanged.connect(lambda s: setattr(settings, "invert_y", bool(s)))
        gl.addWidget(invert)
        layout.addWidget(g)
        layout.addStretch()
        return w

    # ---------------- runtime ----------------
    def _push_config(self):
        push_config_to_clients()
        log("Pushed updated lens config to connected client(s).")

    def _append_log(self, line):
        self.log_box.appendPlainText(line)

    def _refresh_status(self):
        state = "RUNNING" if settings.running else "Stopped"
        self.status_label.setText(f"{state}  |  Clients connected: {settings.connected_clients}")

    def start_server(self):
        settings.running = True
        ips = get_local_ips()
        lines = [f"http://{ip}:{settings.port}" for ip in ips] or ["No network interface found yet — plug in USB & enable tethering."]
        self.ip_display.setPlainText("\n".join(lines))
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        log("Server started. Waiting for phone to connect...")

    def stop_server(self):
        settings.running = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        log("Server stopped (still listening for HTTP, but no frames are being sent).")


async def main():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
    app.setStyleSheet(DARK_QSS)
    win = MainWindow()
    win.show()

    web_app = build_app()
    runner = web.AppRunner(web_app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", settings.port)
    await site.start()
    log(f"HTTP/WebSocket server listening on 0.0.0.0:{settings.port}")

    asyncio.ensure_future(capture_loop(web_app))

    while win.isVisible():
        await asyncio.sleep(0.05)


if __name__ == "__main__":
    qasync.run(main())
