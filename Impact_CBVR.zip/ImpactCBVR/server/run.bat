@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo Impact CBVR Server - Start
echo ============================================

rem --- 1. Add a temporary Windows Firewall rule for port 4243 ---
echo Setting up a Windows Firewall rule for port 4243 (only while this window is open).
echo A Windows permission prompt will appear now to create the rule.
echo Please click "Yes" to allow it.
powershell -NoProfile -Command "Start-Process netsh -ArgumentList 'advfirewall firewall add rule name="Impact CBVR" dir=in action=allow protocol=TCP localport=4243' -Verb RunAs -Wait"

netsh advfirewall firewall show rule name="Impact CBVR" >nul 2>&1
if %errorlevel% neq 0 (
    echo WARNING: The Firewall rule could not be confirmed.
    echo If the phone cannot connect, create it manually in an elevated Command Prompt:
    echo   netsh advfirewall firewall add rule name="Impact CBVR" dir=in action=allow protocol=TCP localport=4243
) else (
    echo Firewall rule is active.
)

rem --- 2. Install Python dependencies directly into the current Python installation ---
echo Installing required Python packages directly (no virtual environment)...
python -m pip install --user -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Dependency installation failed.
    echo Make sure Python and pip are installed and available as "python" and "pip".
    echo You may need to run this file from an account with permission to install Python packages.
    pause
    exit /b 1
)

echo.
echo Starting Impact CBVR. To stop it, close this window or press CTRL+C.
echo.
python server.py

rem --- 3. Remove the temporary Firewall rule when the server exits ---
echo.
echo Server stopped. Removing the temporary Firewall rule...
powershell -NoProfile -Command "Start-Process netsh -ArgumentList 'advfirewall firewall delete rule name="Impact CBVR"' -Verb RunAs -Wait"
echo Firewall rule removed. Done.
pause
